<?php
abstract class Subject extends Table{
    abstract function validate(){
        return false;
    }
        public $subject_id  = 0;  
    public $name  = '';  
    public $otdel_id  = 0;  
    public $hours = '';  
    public $active  = 1;   
}