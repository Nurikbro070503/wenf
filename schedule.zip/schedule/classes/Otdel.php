<?php
abstract class Otdel extends Table{
    abstract function validate(){ 
        return false;
    } 
    public $otdel_id = 0;
public $name = '';
public $active = 1;
}