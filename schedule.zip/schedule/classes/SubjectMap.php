<?php
abstract class SubjectMap extends BaseMap{
    function arrSubjects(){
        $res = $this->db->query("SELECT subject_id AS id, name AS
value FROM subject");
return $res->fetchAll(PDO::FETCH_ASSOC);
    }
}