<?php
abstract class Student extends Table{
    abstract function validate(){
        return false;
    }
        public $user_id  = 0;
    public $gruppa_id  = 0;
    public $num_zach  = '';  
}