<?php
abstract class Special extends Table{
    abstract function validate(){       
        return false;
    }
        public $special_id  = 0;
    public $name  = '';  
    public $otdel_id  = 0;  
    public $active  = 1;  
}